#include <iostream>
#include <string>

using namespace std;

class Student {
private:
    string name;
    int grade;
    string courses[10]; // Assuming a maximum of 10 courses

public:
   
    Student(string name, int grade) {
        this->name = name;
        this->grade = grade;
    }

    void addCourse(const string& course);
    void removeCourse(const string& course);
    void displayInfo() const;
};

    void Student::addCourse(const string& course) {
        for (int i = 0; i < 10; ++i) {
            if (courses[i].empty()) {
                courses[i] = course;
                cout << "Course \"" << course << "\" added successfully." << endl;
                return;
            }
        }
        cout << "Cannot add more courses. Course limit reached." << endl;
    }

      void Student::removeCourse(const string& course) {
        for (int i = 0; i < 10; ++i) {
            if (courses[i] == course) {
                courses[i] = ""; // Remove the course
                cout << "Course \"" << course << "\" removed successfully." << endl;
                return;
            }
        }
        cout << "Course \"" << course << "\" not found." << endl;
    }

    void Student::displayInfo() const {
        cout << "Name: " << name << ", Grade: " << grade << endl;
        cout << "Courses: ";
        bool empty = true;
        for (int i = 0; i < 10; ++i) {
            if (!courses[i].empty()) {
                if (!empty)
                    cout << ", ";
                cout << courses[i];
                empty = false;
            }
        }
        if (empty)
            cout << "No courses registered." << endl;
        else
            cout << endl;
    }

int main() {
    
    Student stud("Ayush Kumar", 10);

    stud.addCourse("Geogrpahy");
    stud.addCourse("Political Science");
    stud.addCourse("Physical Education");

    stud.displayInfo();

    stud.removeCourse("Political Science");

    stud.displayInfo();

    return 0;
}
