#include<iostream>
#include<conio.h>

using namespace std;

class xyz
{
private:
    int a;
    float b;
public:
    xyz(int x, float y){
        a=x;
        b=y;
    }
    xyz(xyz &obj){
        a=obj.a;
        b=obj.b;
    }
    
    void display(){
        cout<<"Value of a is: "<<a<<endl;
        cout<<"Value of b is: "<<b<<endl;
    }
};

int main()
{
    xyz obj(5,7.5);
    xyz obj2(obj);
    xyz obj3=obj;
    obj.display();
    obj2.display();
    obj3.display();
    return 0;
}
