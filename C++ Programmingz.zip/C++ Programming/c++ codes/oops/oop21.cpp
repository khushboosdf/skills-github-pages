#include<iostream>
#include<conio.h>

using namespace std;

class abc
{
private:
    int a,b;
public:
    abc(int x, int y){
        a=x;
        b=y;
    }
   
    void display(){
        cout<<"The sum of a and b is: "<<a+b<<endl;
    }
};

int main()
{
    abc obj(2,3);
    obj.display();   
    return 0;
}
