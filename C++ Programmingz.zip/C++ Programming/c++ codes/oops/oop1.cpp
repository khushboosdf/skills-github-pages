#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

class person
{
private:
   char name[20];
   int age;
public:
    person(char n[], int a){
        strcpy(name,n);
        age=a;
    }

    void display()
    {
    cout<<"Name is: "<<name<<endl;
    cout<<"Age is: "<<age<<endl;
    }
};

int main()
{
    person obj1("gagan",18), obj2("ayush",20);
    obj1.display();
    obj2.display();
    return 0;
}
