#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

class Circle
{
private:
   float radius;
   float pi=3.14;
public:
    void calculatetheareaandcircumference();
    void displaytheareaandcircumference();
};

    void Circle:: calculatetheareaandcircumference(){
        cout<<"Enter Radius: ";
        cin>>radius;
    }

    void Circle:: displaytheareaandcircumference(){
        calculatetheareaandcircumference();
        cout<<"The area of the Circle is: "<<pi*radius*radius<<endl;
        cout<<"The circumference of the circle is: "<<2*pi*radius<<endl;
    }
    
int main()
{
    Circle obj;
    obj.displaytheareaandcircumference();
    return 0;
}
