#include<iostream>

using namespace std;

class Employee
{
	char name[20];
	int salary;
	int date,month,year;
	public:
		void get();
		void service(int y,int m,int d);
};

	void Employee::get()
		{
			cout<<endl<<"Enter Name : ";
			cin>>name;
			cout<<"Enter Salary : ";
			cin>>salary;
			cout<<"Enter year of hire : ";
			cin>>year;
			cout<<"Enter month of hire : ";
			cin>>month;
			cout<<"Enter day of hire : ";
			cin>>date;
		}

	void Employee::service(int y,int m,int d)
		{
			cout<<endl<<"Date of hiring : "<<date<<"-"<<month<<"-"<<year;
			if(m<month && d<date)
			{
				cout<<endl<<"Years of service : "<<(y-year)<<" years "<<(-(m-month))<<" months "<<(-(d-date))<<" days";
			}
			else if(m<month)
			{
				cout<<endl<<"Years of service : "<<(y-year)<<" years "<<(-(m-month))<<" months "<<(d-date)<<" days";
			}
			else if(d<date)
			{
				cout<<endl<<"Years of service : "<<(y-year)<<" years "<<(m-month)<<" months "<<(-(d-date))<<" days";
			}
			else
			{
				cout<<endl<<"Years of service : "<<(y-year)<<" years "<<(m-month)<<" months "<<(d-date)<<" days";
			}
		}

int main()
{
	int date,month,year;
	Employee e1,e2;
	year=2024;
	cout<<"Enter today's month : ";
	cin>>month;
	cout<<"Enter today's date : ";
	cin>>date;
	cout<<"Present Date : "<<date<<"-"<<month<<"-"<<year;
	e1.get();
	e2.get();
	e1.service(year,month,date);
	e2.service(year,month,date);
}