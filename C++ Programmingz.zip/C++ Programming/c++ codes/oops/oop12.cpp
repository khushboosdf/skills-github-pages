#include <iostream>

using namespace std;

class Airplane
{

private:
    int flightNumber;
    char destination[20];
    int departureTime;

public:
    void get();
   void status();
};

     void Airplane::get()
    {
        cout << "Enter flight number : ";
        cin >> flightNumber;
        cout << "Enter Destination name : ";
        cin >> destination;
        cout << "Enter flight time : ";
        cin >> departureTime;
    }

    void Airplane::status() {
        int currentTime = 12; // Current time ( 12PM)
        if (currentTime > departureTime) {
            cout << "Flight " << flightNumber << " to " << destination << " is delayed." << endl;
        } else {
            cout << "Flight " << flightNumber << " to " << destination << " is on time." << endl;
        }
    }

int main()
{
    Airplane obj;
    obj.get();
    obj.status();
}