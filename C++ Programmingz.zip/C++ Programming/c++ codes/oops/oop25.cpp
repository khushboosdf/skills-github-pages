#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

class Person
{
private:
    char name[20];
    int age;
    char country[20];
public:
    Person(char n[], int a, char c[]){
        strcpy(name,n);
        age=a;
        strcpy(country,c);
    }

    char* getname(){
        return name;
    }

    int getage(){
        return age;
    }

    char* getcountry(){
        return country;
    }

    void setname(char a[]){
        strcpy(name,a);
    }

    void setage(int b){
        age=b;
    }
    
    void setcountry(char c[]){
        strcpy(country,c);
    }
   
};

int main()
{
    Person obj("Gagan",18,"India");
    cout<<"Initial Values: "<<endl;
    cout<<"Your Name is: "<<obj.getname()<<endl;
    cout<<"Your Age is: "<<obj.getage()<<endl;
    cout<<"Your Country Name is: "<<obj.getcountry()<<endl;

    obj.setname("Smith");
    obj.setage(35);
    obj.setcountry("Australia");

    cout<<"\nUpdated Values: "<<endl;
    cout<<"Your Name is: "<<obj.getname()<<endl;
    cout<<"Your Age is: "<<obj.getage()<<endl;
    cout<<"Your Country Name is: "<<obj.getcountry()<<endl;
    return 0;
}
