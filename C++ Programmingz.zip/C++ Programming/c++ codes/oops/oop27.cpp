#include<iostream>
#include<conio.h>

using namespace std;

class Rectangle
{
private:
    int length, width;
public:
    Rectangle(int l, int w){
        length=l;
        width=w;
    }

    int getlength(){
        return length;
    }

    int getwidth(){
        return width;
    }

    void setlength(int l){
        length=l;
    }

    void setwidth(int w){
        width=w;
    }
   
};

int main()
{
    Rectangle obj(5,10);
    cout<<"Initial Length and Width: "<<endl;
    cout<<"Length of the rectangle is: "<<obj.getlength()<<endl;
    cout<<"Width of the rectangle is: "<<obj.getwidth()<<endl;

    obj.setlength(10);
    obj.setwidth(20);

    cout<<"\nUpdated Length and Width: "<<endl;
    cout<<"Length of the rectangle is: "<<obj.getlength()<<endl;
    cout<<"Width of the rectangle is: "<<obj.getwidth()<<endl;
    return 0;
}
