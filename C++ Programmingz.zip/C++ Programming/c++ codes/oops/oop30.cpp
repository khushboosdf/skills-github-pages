#include <iostream>
#include <string>

using namespace std;

class Car {
private:
    string comp;
    string modl;
    int year;
    double mile;

public:
    void sComp(string company) {
        comp = company;
    }

    void sModl(string model) {
        modl = model;
    }

    void sYear(int yr) {
        year = yr;
    }

    void uMile(double dist, double fuel) {
        if (fuel > 0) {
            mile = dist / fuel;
        } else {
            cout << "Error: Fuel consumption cannot be zero or negative." << endl;
        }
    }

    string gComp() const {
        return comp;
    }

    string gModl() const {
        return modl;
    }

    int gYear() const {
        return year;
    }

    double gMile() const {
        return mile;
    }
};

int main() {
    Car myCar;

    myCar.sComp("Mahindra");
    myCar.sModl("Thar");
    myCar.sYear(2020);

    double dist = 3000.0;
    double fuel = 200.0;
    myCar.uMile(dist, fuel);

    cout << "Company Name: " << myCar.gComp() << endl;
    cout << "Model Name: " << myCar.gModl() << endl;
    cout << "Year: " << myCar.gYear() << endl;
    cout << "Mileage: " << myCar.gMile() << " km/l" << endl;

    return 0;
}
