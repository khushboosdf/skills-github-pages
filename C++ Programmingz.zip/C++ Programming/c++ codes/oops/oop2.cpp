#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

class dog
{
private:
   char name[20];
   char breed[20];
public:
    dog(char a[], char b[]){
        strcpy(name,a);
        strcpy(breed,b);
    }

    void setname(char a[]){
         strcpy(name,a);
    }

    void setbreed(char b[]){
         strcpy(breed,b);
    }

    void display()
    {
    cout<<"Name is: "<<name<<endl;
    cout<<"Breed is: "<<breed<<endl;
    }
     
};


int main()
{
    dog obj1("Bruno","Pitbull"), obj2("Tyson","German Shpeherd");

    //Displaying Initial Values
    cout<<"Initial Values: "<<endl;
    obj1.display();
    obj2.display();

    //Modifying Attributes
    obj1.setname("Rocky");
    obj2.setbreed("Bull Dog");
    obj1.setname("Romeo");
    obj2.setbreed("Bully Bultair");

    cout<<endl;
    //Displaying Modified Values
    cout<<"Modified Values: "<<endl;
    obj1.display();
    obj2.display();
    return 0;
}
