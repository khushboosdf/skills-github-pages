
#include <iostream>

using namespace std;

class Vehicle{
    public:
    virtual void drive(){
        cout<<"VEHICLE DRIVING"<<endl;
    }
};

class Car : public Vehicle{
    public:
    void drive() override{
        cout<<"REPAIRING A CAR"<<endl;
    }
};

int main() {
    Vehicle v;
    Car c;
    v.drive();
    c.drive();
    return 0;
}