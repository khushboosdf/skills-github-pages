#include <iostream>

using namespace std;

class Person{
    public:
    string fname,lname;
    virtual void getLastname(){
        cout<<"ENTER LAST NAME : ";
        cin>>lname;
    }
    void getFirstName(){
        cout<<"ENTER FIRST NAME : ";
        cin>>fname;
    }
    void displayInfo(){
        cout<<"EMPLOYEE : "<<fname<<" "<<lname<<endl;
    }
};

class Employee : public Person{
    int id;
    string job;
    public:
    void getLastname() override{
        cout<<"ENTER LAST NAME AND JOB : ";
        cin>>lname>>job;
    }
    void getEmployeeId(){
        cout<<"ENTER ID : ";
        cin>>id;
    }
    void displayInfo(){
        cout<<"EMPLOYEE "<<id<<" : "<<fname<<" "<<lname<<"("<<job<<")"<<endl;
    }
};

int main() {
    Person p;
    Employee e;
    p.getFirstName();
    p.getLastname();
    e.getFirstName();
    e.getLastname();
    e.getEmployeeId();
    p.displayInfo();
    e.displayInfo();
    return 0;
}