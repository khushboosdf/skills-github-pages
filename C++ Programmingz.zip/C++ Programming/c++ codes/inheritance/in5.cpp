#include <iostream>

using namespace std;

class BankAccount{
    public:
    int balance;
    void deposit(int amount){
        cout<<"DEPOSITING : "<<amount<<endl;
        balance += amount;
        cout<<"BALANCE : "<<balance<<endl;
    }
    virtual void withdraw(int amount){
        cout<<"WITHDRWAING : "<<amount<<endl;
        balance -= amount;
        cout<<"BALANCE : "<<balance<<endl;
    }
};

class SavingAccount : public BankAccount{
    public:
    void withdraw(int amount) override{
        if ((balance-amount)>100)
        {
            cout<<"WITHDRWAING : "<<amount<<endl;
            balance -= amount;
        }
        else{
            cout<<"MINIMUM BALANCE REACHED ! TRANSACTION FAILED !"<<endl;
        }
        cout<<"BALANCE : "<<balance<<endl;
    }
};

int main() {
    BankAccount ba;
    SavingAccount sa;
    ba.balance = 3000;
    sa.balance = 5000;
    ba.deposit(7000);
    ba.withdraw(8000);
    sa.deposit(6000);
    sa.withdraw(7500);
    return 0;
}