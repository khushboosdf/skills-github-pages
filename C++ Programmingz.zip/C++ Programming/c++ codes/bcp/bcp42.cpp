#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n, fact=1;
cout<<"Enter number: "<<endl;
cin>>n;

for(int i=1; i<=n; i++)
{
  fact=fact*i;
}
cout<<"The factorial of "<<n<<" is: "<<fact<<endl;   
     return 0;
}