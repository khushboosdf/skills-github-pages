#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    cout<<"Time: "<<__TIME__<<"and Date: "<<__DATE__<<endl;
    return 0;
}