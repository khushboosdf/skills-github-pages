#include<iostream>
#include<conio.h>
using namespace std;
 
 int main()
 {
    int n, a, r, sum=0;
    cout<<"Enter any Positive Number: "<<endl;
    cin>>n;
    a=n;
    while (n>0)
    {
        r=n%10;
        sum=r+(sum*10);
        n=n/10;
    }
    if (a==sum)
    {
       cout<<a<<" is a Palindrome Number";
    }
    else{
         cout<<a<<" is not a Palindrome Number";
    }
    return 0;
 }
 