#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n,r,c,sum=0;
    cout<<"Enter any Positive integer: "<<endl;
    cin>>n;
    c=n;
    while(n>0){
        r=n%10;
        sum=r+sum;
        n=n/10;
    }

    cout<<"The Sum of digits of "<<c<<" is: "<<sum<<endl;
    return 0;
}
