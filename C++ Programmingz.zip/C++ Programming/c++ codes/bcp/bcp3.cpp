#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a;
int b;
cout<<"Enter the first value: "<<endl;
cin>>a;
cout<<"Enter the second value: "<<endl;
cin>>b;
cout<<"The product of first and second value is: "<<a*b<<endl;
return 0;
}

