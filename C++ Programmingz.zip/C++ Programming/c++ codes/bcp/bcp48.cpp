#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;

int main()
{
double x1,x2,y1,y2;
cout<<"Enter the coordinates of x: "<<endl;
cin>>x1>>x2;
cout<<"Enter the coordinates of y: "<<endl;
cin>>y1>>y2;

cout<<"The distance between x and y is: "<<sqrt( pow((x2-x1),2) + pow((y2-y1),2) )<<endl;   
    
     return 0;
}