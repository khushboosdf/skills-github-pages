#include<iostream>
#include<conio.h>
using namespace std;
int main()
{
    int n, r, sum=0;
    cout<<"Enter any number: "<<endl;
    cin>>n;
    while(n>0){
        r=n%10;
        sum=sum+r;
        n=n/10;
    }
    cout<<"Sum of digits of integer is: "<<sum<<endl;
    return 0;
}
