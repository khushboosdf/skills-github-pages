#include<iostream>
#include<conio.h>
#include<cmath>

using namespace std;

int main()
{
int a,b;
cout<<"Enter the number and A and B (B/A) : "; 
cin>>a>>b;
cout<<"Rounded result of integer division : "<<round((float)b/a);       
    return 0;
}