#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
cout<<"The First Five natural numbers are: "<<endl;
for(int i=1; i<=5; i++)
{
cout<<i<<endl;
}   
    return 0;
}