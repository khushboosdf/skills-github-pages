#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int month;
cout<<"Enter the Number of month: "<<endl;
cin>>month;

switch(month) {
    case 1:
    cout<<"The number of days in January is: 31"<<endl;
    break;
    case 2:
    cout<<"The number of days in February is: 28 in common or 29 in leap year"<<endl;
    break;
    case 3:
    cout<<"The number of days in March is: 31"<<endl;
    break;
    case 4:
    cout<<"The number of days in April is: 30"<<endl;
    break;
    case 5:
    cout<<"The number of days in May is: 31"<<endl;
    break;
    case 6:
    cout<<"The number of days in June is: 30"<<endl;
    break;
    case 7:
    cout<<"The number of days in July is: 31"<<endl;
    break;
    case 8:
    cout<<"The number of days in August is: 31"<<endl;
    break;
    case 9:
    cout<<"The number of days in September is: 30"<<endl;
    break;
    case 10:
    cout<<"The number of days in October is: 31"<<endl;
    break;
    case 11:
    cout<<"The number of days in November is: 30"<<endl;
    break;
    case 12:
    cout<<"The number of days in December is: 31"<<endl;
    break;
    }   
    
    return 0;
}