#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int i, x, r, sum;
    cout<<"Armstrong Numbers are: "<<endl;
    for(i=1; i<=600; i++){
        sum=0;
        x=i;
        while (x!=0)
        {
            r=x%10;
            sum=sum+r*r*r;
            x=x/10;
        }
        if(i==sum){
            cout<<i<<" ";
        }
    }
    
    return 0;
}