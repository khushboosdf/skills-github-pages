#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int height,breadth;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"Enter Breadth: "<<endl;
cin>>breadth;
cout<<"The area of Triangle is: "<<0.5*height*breadth<<endl;       
    return 0;
}