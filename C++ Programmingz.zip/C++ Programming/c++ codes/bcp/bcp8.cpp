#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int a=0;
    long n,p=1;
    cout<<"Enter the Number in binary: ";
    cin>>n;

    int r,b;
    b=n;

    while(n>0){
    r=n%10;
    a=a+(r*p);
    n=n/10;
    p=p*2;
    }

    cout<<"Decimal value of "<<b<<" is: "<<a;
    return 0;
}