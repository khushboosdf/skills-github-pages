#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n,a;
cout<<"Enter Number: "<<endl;
cin>>n;
cout<<endl<<endl;

cout<<"The Multiplication table of "<<n<<" is: "<<endl;
for(int i=1;i<=10;i++)
{
 a=n*i;
 cout<<a<<endl;
}    
    
    return 0;
}