#include<iostream>

using namespace std;

int main()
{
int length,breadth,height;
cout<<"Enter Length: "<<endl;
cin>>length;
cout<<"Enter Breadth: "<<endl;
cin>>breadth;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"The Volume of Cuboid is: "<<length*breadth*height<<endl;
    return 0;
}
