#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b;
int t;
cout<<"Enter a: "<<endl;
cin>>a;
cout<<"Enter b: "<<endl;
cin>>b;
t=a;
a=b;
b=t;
cout<<"The new value for a is: "<<a<<endl;
cout<<"The new value for b is: "<<b<<endl;  
return 0;
}