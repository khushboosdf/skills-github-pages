#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n,i,count=0;
    cout<<"Enter number: "<<endl;
    cin>>n;
    
    for(i=2; i<=n;i++){
        if (n%i==0)
        {
        count=count+1;
        }
    }
       if (count==1)
       {
        cout<<n<<" is a Prime Number";
       }
       else{
        cout<<n<<" is not a Prime Number";
       }
       
    return 0;
}