#include<iostream>
using namespace std;
int main()
{
   int a=0,b=0;
   for(int i=2;i<101;i++){
    b=0;
    for(int j=2;j<i;j++){
       if(i%j==0){
          b=1;        
       }
    }
    if(b==0){
        a=a+i;
    }
   }
   cout<<"Sum Of First 100 Prime No. : "<<a;
   return 0;
 }