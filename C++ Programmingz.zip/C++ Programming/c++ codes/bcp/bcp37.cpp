#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int radius,height;
cout<<"Enter Radius: "<<endl;
cin>>radius;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"The surface area of cylinder is: "<<(2*3.14*radius*height)+(2*3.14*radius*radius)<<endl;       
    return 0;
}