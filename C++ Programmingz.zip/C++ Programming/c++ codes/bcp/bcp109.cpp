#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n;
float f;
cout<<"Enter the Double number : "; 
cin>>f;

n=f;

if(n==f){
    cout<<"Double number is an integer";
}
else{
    cout<<"Double number is not an integer";
}
    
    return 0;
}