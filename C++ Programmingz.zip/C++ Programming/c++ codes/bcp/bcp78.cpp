#include <iostream>
#include <string>

using namespace std;

int main() {
    string html = "<p>HTML string <b>with</b> tags <i>of HTML</i>.</p>";
    string clean;
    bool tag = false;
   
    for (int i=0;i<html.length();i++) {
        char c=html[i];
        if (c == '<') {
            tag = true;
            continue;
        }
        if (c == '>') {
            tag = false;
            continue;
        }
        if (!tag) {
            clean += c;
        }
    }

    cout << "Cleaned String: " << clean << endl;

    return 0;
}
