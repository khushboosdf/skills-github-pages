#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int radius;
cout<<"Enter Radius: "<<endl;
cin>>radius;
cout<<"The Volume of Sphere is: "<<1.33*3.14*radius*radius*radius<<endl;    
    return 0;
}