#include<iostream>
#include<conio.h>

using namespace std;
int main()
{
int a,b,c;
cout<<"Enter First Value: "<<endl;
cin>>a;
cout<<"Enter Second Value: "<<endl;
cin>>b;
cout<<"Enter Third Value: "<<endl;
cin>>c;

if(a>b){
  if(a>c){
    cout<<"The values are in decreasing order";
  }
}
else if(b<c){
  cout<<"The values are in increasing order";
}
else{
  cout<<"The values are nor in increasing or neither in decreasing order";
}
return 0;
}