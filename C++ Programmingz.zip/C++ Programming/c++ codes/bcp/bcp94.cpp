#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n,i,sum=0;
    cout<<"Enter n number: "<<endl;
    cin>>n;
    for(i=1;i<=n;i++){
        sum=sum+i;
    }
    cout<<"Sum of n number: "<<sum;
    return 0;
}