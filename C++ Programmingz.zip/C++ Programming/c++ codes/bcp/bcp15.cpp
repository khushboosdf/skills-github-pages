#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    cout<<"Time of system is: "__TIME__<<endl;
    return 0;
}