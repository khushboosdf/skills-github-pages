#include<iostream>

using namespace std;

int main()
{
int radius,height;
cout<<"Enter Radius: "<<endl;
cin>>radius;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"The Volume of Cylinder is: "<<0.33*3.14*radius*radius*height<<endl;
    return 0;
}
