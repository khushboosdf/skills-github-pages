#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;

int main()
{
 int n;
cout<<"Enter number: "<<endl;
cin>>n;
cout<<"The square root of number is: "<<sqrt(n)<<endl;     
 return 0;
}