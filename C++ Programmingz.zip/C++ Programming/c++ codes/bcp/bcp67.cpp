#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
    char str1[50], str2[30];
	cout<<"Enter String 1: "<<endl;
	cin>>str1;
	cout<<"Enter String 2: "<<endl;
	cin>>str2;
	strcat(str1,str2);

	cout<<"The Concatenate String is: "<<str1<<endl;   
    
    return 0;
}