#include<iostream>
#include<string>
using namespace std;
int main()
{
string str="This is\n the 79th\n program\n of\n  Basic Contsruct Prorgrams";
cout<<"String : "<<endl<<str;
int n=1;
for(int i=0;i<str.length();i++){ 
     if(str[i]=='\n'){
        n++;
     }
}
cout<<endl<<"Total number of lines : "<<n;
return 0;
}