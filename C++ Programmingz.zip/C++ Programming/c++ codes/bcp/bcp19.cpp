#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int sec;
	cout<<"Enter time in second : ";
	cin>>sec;
	int min=sec/60;
	int h=min/60;
	cout<<"Time in minutes : "<<min<<" minutes "<<(sec%60)<<" seconnds"<<endl;
	cout<<"Time in hour : "<<h<<" hours "<<(sec%3600)/60<<" minutes "<<(sec%3600)%60<<" seconds";
    
    return 0;
}