#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int a,b,c;
	cout<<"Enter first value: "<<endl;
	cin>>a;
	cout<<"Enter second value: "<<endl;
	cin>>b;
	cout<<"Enter third value: "<<endl;
	cin>>c;

	cout<<"The average of these values is: "<<(a+b+c)/3<<endl;    
    
    return 0;
}