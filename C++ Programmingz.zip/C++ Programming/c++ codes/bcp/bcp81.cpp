#include<iostream>
#include<conio.h>
 
 using namespace std;
int main()
{
    cout<<"Numbers between 1 to 10 are: "<<endl;
    for (int i = 1; i <= 10; i++)
    {
        cout<<i<<endl;
    }
    
    return 0;
}
