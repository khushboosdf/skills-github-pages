#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int length,height,breadth;
cout<<"Enter Length: "<<endl;
cin>>length;
cout<<"Enter Height: "<<endl;
cin>>height;
cout<<"Enter Breadth: "<<endl;
cin>>breadth;
cout<<"The surface area of cuboid is: "<<2*(length*height+breadth*height+length*breadth)<<endl;     
    return 0;
}