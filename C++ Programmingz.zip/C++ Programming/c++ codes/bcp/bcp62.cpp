#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n,c=0;
	int m;
	cout<<"Enter any positive number : ";
	cin>>n;
	if(n>0)
	{
		m=n;
		while(m!=0)
		{
			m=m/10;
			c++;
		}
		cout<<endl<<"Number of digites in "<<n<<" are : "<<c;
	}
	else
	{
		cout<<endl<<"Entered number is negative";
	}
    
    return 0;
}