#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int units,bill;
cout<<"Enter units: "<<endl;
cin>>units;
if(units<=100)
{
bill = units*5;
}
else if(units>100 && units<=200)
{
bill = 100*5 + (units-100)*10;
}
else if(units>200 && units<=300)
{
bill = 100*5 + 100*10 + (units-200)*15;
}
else
{
bill = 100*5 + 100*10 + 100*15 + (units-300)*20;
}
cout<<"Your bill is: "<<bill<<endl;   
   return 0;
}