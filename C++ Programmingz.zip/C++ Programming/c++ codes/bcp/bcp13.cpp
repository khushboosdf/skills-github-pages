#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
char ch;
cout<<"Enter any character: "<<endl;
cin>>ch;
cout<<"The ASCII value of the enter character is: "<<(int)ch<<endl;
 return 0;
}