#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

int main()
{
    string str;
    int i;
    int n=0,l=0,s=0,o=0;
    cout<<"Enter the string : ";
    getline(cin,str);

    for(i=0;i<str.length();i++){
        if(isalpha(str[i])){
            l++;
        }
        else if(isdigit(str[i])){
            n++;
            }
        else if(str[i]==' '){
            s++;
        }
        else
            o++;
    }

    cout<<"Number of Letters : "<<l<<endl;
    cout<<"Number of Digit characters : "<<n<<endl;
    cout<<"Number of Spaces : "<<s<<endl ;
    cout<<"Number of other characters : "<<o<<endl ;
    return 0;
}