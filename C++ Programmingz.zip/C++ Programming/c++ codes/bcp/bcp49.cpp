#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;

int main()
{
int base_value,power,result;

cout<<"Enter Base Value: "<<endl;
cin>>base_value;
cout<<"Enter Power: "<<endl;
cin>>power;

cout<<"The result of power is: "<<pow(base_value,power)<<endl;  
    
    return 0;
}