#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
 int radius;
cout<<"Enter Radius: "<<endl;
cin>>radius;
cout<<"The area of circle is: "<<3.14*radius*radius<<endl;     
    return 0;
}