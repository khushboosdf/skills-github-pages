#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int a,b,c;
cout<<"Enter First Value: "<<endl;
cin>>a;
cout<<"Enter Second Value: "<<endl;
cin>>b;
cout<<"Enter Third Value: "<<endl;
cin>>c;

if(a==b && a==c)
{
cout<<"The First, Second and Third value are equal"<<endl;
}
else
{
cout<<"The First, Second and Third value are not equal"<<endl;
}   
    
    return 0;
}