#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
char ch;
cout<<"Enter character: "<<endl;
cin>>ch;
char a,e,i,o,u;
if(ch==a && ch==e && ch==i && ch==o && ch==u){
cout<<"It is a vowel"<<endl;
}
else{
cout<<"It is a consonant"<<endl;
}
     return 0;
}






