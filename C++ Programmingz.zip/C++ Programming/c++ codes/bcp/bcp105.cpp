#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
    int n1,n2;
    cout<<"Enter First Number: ";
    cin>>n1;
    cout<<"Enter Second Number: ";
    cin>>n2;

    int tn1=n1, tn2=n2;

    while (n1 % n2 != 0)
    {
        int r = n1 % n2;
        n1 = n2;
        n2 = r;
    }
    
    cout<<"GCD of two numbers is: "<<n2<<endl;

    int lcm = (tn1 * tn2)/n2;
    cout<<"LCM of two numbers is:  "<<lcm<<endl;
    return 0;
}