#include<iostream>
#include<conio.h>
using namespace std;

int fib(int n){
    if(n==1 || n==2){
        return 1;
    }
    else{
        return fib(n-2) + fib(n-1);
    }
}

int main()
{
    int a,n;
    cout<<"Enter number of terms: "<<endl;
    cin>>n;
    cout<<"The Fibonacci Series of n  terms: "<<endl;
    for(a=1; a<=n;a++){
        cout<<fib(a)<<endl;
    }
    
    return 0;
}