#include<iostream>
#include<conio.h>
#include<string.h>
using namespace std;

int main()
{
    char s1[100];
    cout<<"Enter String: "<<endl;
    cin>>s1;
    
    strrev(s1);
    cout<<"Your string is: "<< s1<<endl;
    return 0;
}