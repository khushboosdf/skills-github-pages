#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
 int length, width;
cout<<"Enter Length: "<<endl;
cin>>length;
cout<<"Enter Width: "<<endl;
cin>>width;
cout<<"The area of rectangle is: "<<length*width<<endl;     
    return 0;
}