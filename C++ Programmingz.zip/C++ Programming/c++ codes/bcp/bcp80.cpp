#include<iostream>
using namespace std;
int main()
{
int n,sum=0;
cout<<"Enter the no. of subjects : ";
cin>>n;
cout<<"Enter the marks of "<<n<<" subjects : ";
for(int i=0;i<n;i++){
    int temp;
    cin>>temp;
    sum=sum+temp;
}
cout<<"Total marks of student : "<<sum<<endl;
cout<<"Percentage : "<<(float)sum/n<<"%"<<endl;
return 0;
}