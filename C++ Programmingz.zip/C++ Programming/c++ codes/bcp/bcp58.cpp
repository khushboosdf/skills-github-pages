#include<iostream>
#include<conio.h>
using namespace std;

int main()
{
int n, cube;
cout<<"Enter number: "<<endl;
cin>>n;
for(int i=1; i<=n; i++)
{
cout<<"Number is: "<<i<<" and cube of "<<i<<" is: "<<i*i*i<<endl;
}  
    
    return 0;
}