#include<iostream>
#include<conio.h>
#include<math.h>
using namespace std;

int main()
{
float p,i,t,a;
cout<<"Enter the Principal Amount: "<<endl;
cin>>p;
cout<<"Enter Rate of Interest: "<<endl;
cin>>i;
cout<<"Enter the Time Period in years: "<<endl;
cin>>t;

a=pow((1+i/100),t);

cout<<"Compound Interest after "<<t<<" years is: "<<(p*a)-p<<endl;   
    return 0;
}