#include<iostream>
#include<conio.h>
using namespace std;

int factorial(int x);

int main()
{
    int num, fact;
    cout<<"Enter number: ";
    cin>>num;

    fact= factorial(num);

    cout<<"Factorial of "<<num<<" is: "<<fact;
    return 0;
}

int factorial(int x){
    if(x==1){
        return 1;
    }
    else{
        return x*factorial(x-1);
    }
}