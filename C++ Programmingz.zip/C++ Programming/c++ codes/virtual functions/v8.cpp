#include <iostream>

using namespace std;

class Vehicle {
public:
    virtual void startEngine() = 0;
    virtual void stopEngine() = 0;
};

class Car : public Vehicle {
public:
    void startEngine() override {
        cout << "Car engine started.\n";
    }

    void stopEngine() override {
        cout << "Car engine stopped.\n";
    }
};

class Motorcycle : public Vehicle {
public:
    void startEngine() override {
        cout << "Motorcycle engine started.\n";
    }

    void stopEngine() override {
        cout << "Motorcycle engine stopped.\n";
    }
};

int main() {
    Car c;
    Motorcycle m;

    c.startEngine();
    c.stopEngine();

    m.startEngine();
    m.stopEngine();

    return 0;
}

