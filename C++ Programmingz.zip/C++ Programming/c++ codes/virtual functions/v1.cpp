#include <iostream>

using namespace std;

class Animal 
{
public:
    virtual void sound() = 0;
};

class Lion : public Animal 
{
public:
    void sound() override {
        cout << "Roar" << endl;
    }
};

class Tiger : public Animal
 {
public:
    void sound() override 
	{
        cout << "Growl" << endl;
    }
};

int main() 
{
    Lion l;
    Tiger t;

    cout << "Lion sounds: ";
    l.sound();
    cout << "Tiger sounds: ";
    t.sound();

    return 0;
}




