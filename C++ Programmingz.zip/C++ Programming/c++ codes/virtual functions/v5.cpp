#include <iostream>

using namespace std;

class Animal {
public:
    virtual void eat() = 0;
    virtual void sleep() = 0;
};

class Lion : public Animal {
public:
    void eat() override {
        cout << "Lion eats meat" << endl;
    }

    void sleep() override {
        cout << "Lion sleeps in a den" << endl;
    }
};

class Tiger : public Animal {
public:
    void eat() override {
        cout << "Tiger eats meat " << endl;
    }

    void sleep() override {
        cout << "Tiger sleeps in  forests" << endl;
    }
};

class Deer : public Animal {
public:
    void eat() override {
        cout << "Deer eats grass and leaves" << endl;
    }

    void sleep() override {
        cout << "Deer sleeps trees" << endl;
    }
};

int main() {
    Lion l;
    Tiger t;
    Deer d;

    cout << "Lion:" << endl;
    l.eat();
    l.sleep();

    cout << "\nTiger:" << endl;
    t.eat();
    t.sleep();

    cout << "\nDeer:" << endl;
    d.eat();
    d.sleep();

    return 0;
}
