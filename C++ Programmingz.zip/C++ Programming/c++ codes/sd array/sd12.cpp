#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[8]={42,12,43,35,21,25,12,55};
    int sum= 0;

    for(int i=0; i<8; i++){
        sum+=arr[i];
    }
    cout<<"The sum of elements present in this array is: "<<sum;
    return 0;
}
