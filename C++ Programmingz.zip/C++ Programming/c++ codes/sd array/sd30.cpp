#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int p,n;
    int arr[50]={1,3,6,2,5};
   
    cout<<"Enter the specific position and number which you want to insert: ";
    cin>>p>>n;
    for(int i=4; i>=p; i--){
        arr[i+1]=arr[i];
    }
        arr[p]=n;
    cout<<"New Array is: "<<endl;
    for(int i=0; i<6; i++){
        cout<<arr[i]<<'\t';
    }
    return 0;
}