#include<iostream>
#include<conio.h>

using namespace std;

void reverse(int array[], int n);
void print(int array[], int n);

int main()
{
    int array[]={1, 2, 3, 4, 5};

    cout<<"Elements of array before reverse: "<<endl;
     for(int i=0; i<5; i++){
        cout<<array[i]<<'\t';
    }

    cout<<endl;
    
    cout<<"Elements of array after reverse: "<<endl;
    reverse(array,5);
    print(array,5);
    return 0;
}

void print(int array[], int n){
    for(int i=0; i<n; i++){
        cout<<array[i]<<'\t';
    }
}

void reverse(int array[], int n){
        for(int i=0; i<n/2; i++){
        int firstvalue=array[i];
        int secondvalue=array[5-i-1];
        array[i]= secondvalue;
        array[5-i-1]= firstvalue;
}
}