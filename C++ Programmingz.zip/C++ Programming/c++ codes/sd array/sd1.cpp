#include<iostream>
#include<conio.h>

#define MAX_SIZE 100
using namespace std;

int main()
{
    int i,n;
    int array1[MAX_SIZE], array2[MAX_SIZE];
    cout<<"Enter the size of the Array 1: ";
    cin>>n;

    cout<<"Enter elements of Array 1: ";
    for (int i = 0; i<n; i++)
    {
       cin>>array1[i];
    }

    for (int i = 0; i<n; i++)
    {
       array2[i]=array1[i];
    }
    
    cout<<"Elements of first array are: "<<endl;
    for (int i = 0; i<n; i++)
    {
       cout<<array1[i]<<'\t';
    }
    cout<<endl;
    cout<<"Elements of second array are: "<<endl;
    for (int i = 0; i<n; i++)
    {
       cout<<array2[i]<<'\t';
    }
    
    return 0;
}
