#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[8]={1,2,3,4,5,6,7,8};

    int large= arr[0];
    for(int i=0; i<8; i++){
        if(arr[i]>large){
            large=arr[i];
        }
    }
    cout<<"The largest number of this array is: "<<large;
    return 0;   
}
