#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
  int ar[]={54,25,25,23,63,36,23,36,14,63};
  int c=0;
  cout<<"Array before removal of duplicate elements : "<<endl;
  int l=sizeof(ar)/sizeof(int);
  for(int i=0;i<l;i++){
    cout<<ar[i]<<" ";
  }
  
  for(int i=0;i<l;i++){
   c=0;
   for(int j=0;j<l;j++){
     if(ar[i]==ar[j]){
        c++;
        if(c>=2){
           for(int k=j;k<l-1;k++){
              ar[k]=ar[k+1];
           }
            l=l-1;  
        }
     }
   }
  }
    cout<<endl<<"Array after removal of duplicate elements : "<<endl;
    for(int i=0;i<l;i++){
    cout<<ar[i]<<" ";
  }
  return 0;
}
