#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[]={1,2,3,4,10};
    int sum=0;
    int size= sizeof(arr)/sizeof(arr[0]);

    cout<<"The elements of this array is: "<<endl;
    for(int i=0; i<size; i++){
        cout<<arr[i]<<'\t';
    }
    cout<<endl;
    for(int i=0; i<size; i++){
        sum+=arr[i];
    }
    cout<<"The Average value of array elements is: "<<sum/size;
    return 0;
}
