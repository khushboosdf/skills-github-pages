#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[]={0,1,2,3,4,5,6,7,8,9,10};
    int size= sizeof(arr)/sizeof(arr[0]);
    int large= arr[0];
    int small= arr[0];

    for(int i=0; i<size; i++){
        if(arr[i]>large){
            large=arr[i];
        }
    }

    for(int i=0; i<size; i++){
        if(arr[i]<small){
            small=arr[i];
        }
    }

    cout<<"The Largest Value in this array is: "<<large<<endl;
    cout<<"The Smallest Value in this array is: "<<small<<endl;

    cout<<"The Difference Between the Largest and Smallest value is: "<<large-small;
    return 0;
}
