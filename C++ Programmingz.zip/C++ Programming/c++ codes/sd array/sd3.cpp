#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
  int arr[10],n;
  cout<<"Enter the no. of elements of array: ";
  cin>>n;

  cout<<"Enter the elements of arrays : "; 
  for(int i=0;i<n;i++){
    cin>>arr[i];
  }

  int b=arr[0];
  for(int i=0;i<n-1;i++){
    arr[i]=arr[i+1];
  }

    arr[n-1]=b;

  cout<<"Elements of array after left rotate : "<<endl;
  for(int i=0;i<n;i++){
    cout<<arr[i]<<"  ";
  }

  return 0;
  }
