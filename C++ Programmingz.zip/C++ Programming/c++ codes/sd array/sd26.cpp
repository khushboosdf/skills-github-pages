#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
  int arr[]={2,32,15,14,43,17,51,1};
  int n;
  
  cout<<"Array : "<<endl;
  int l=sizeof(arr)/sizeof(int);
  for(int i=0;i<l;i++){
    cout<<arr[i]<<" ";  
  }

  cout<<endl<<"Enter the element you want index : ";
  cin>>n;
  int i;
  for(i=0;i<l;i++){
     if(arr[i]==n){
       break;
     }
  }

  if(i==l){
    cout<<"No such element ";
  }
  else{
  cout<<"Index of the element  : "<<i<<endl;
  }
  return 0;
  }
