#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int arr[8]={1, 2, 3, 4, 5, 6, 7, 8};

    cout<<"Elements of array present on odd position are: "<<endl;
    for(int i=1; i<8; i+=2){
            cout<<arr[i]<<'\t';
    }
    return 0;
}
