#include<iostream>
#include<conio.h>

using namespace std;

int frequency(int a[],int num,int b);

int main()
{
  int arr[10],rn[10],n,c=0,in=0;
  cout<<"Enter the no. of elements of array: ";
  cin>>n;
  cout<<"Enter the elements of arrays : "; 
  for(int i=0;i<n;i++){
    cin>>arr[i];
  }
  for(int i=0;i<n;i++){
    int c=0;
    for(int j=0;j<n;j++){
      if(arr[i]==arr[j]){
          c++;
      }
    }
    if(frequency(rn,arr[i],in)){
    rn[in]=arr[i];
    in++;
    cout<<"Frequency of "<<arr[i]<<" : "<<c<<endl;
        }
    }
  return 0;
  }

  int frequency(int a[],int num,int b){
  for(int i=0;i<b;i++){
  if (a[i]==num){
    return 0;
        }
    }     
  return 1;
}
