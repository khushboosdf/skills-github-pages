#include<iostream>

using namespace std;

int main()
{
    int a=0,b=1,c,temp;
    cout<<"Enter the octal number: ";
    cin>>c;
    while(c!=0){
        temp=c%10;
        a=a+(b*temp);
        c=c/10;
        b=b*8;
    }
    cout<<"Decimal number after converion is: "<<a;
    return 0;
}
