#include<iostream>
#include<string>

using namespace std;

int main()
{
    string str;
    long n=0;
    cout<<"Enter the integers for string : ";
    cin>>str;
    cout<<"String value after conversion into long : "<<stol(str);
    return 0;
}
