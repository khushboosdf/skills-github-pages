#include<iostream>
#include<string>
using namespace std;
int main()
{
    float a;
    string str="";
    cout<<"Enter the string which you want to convert it into float : ";
    cin>>str;
    a=stof(str);
    cout<<"String after conversion into float : "<<a;
    return 0;
}

