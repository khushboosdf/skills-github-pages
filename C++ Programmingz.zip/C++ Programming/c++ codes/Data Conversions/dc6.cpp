#include<iostream>
#include<string.h>
#include<sstream>

using namespace std;

int main()
{
    stringstream ssr;
    string str="";
    float a;
    cout<<"Enter the float which you want to convert it into string : ";
    cin>>a;
    ssr<<a;
    ssr>>str;
    cout<<"Float after conversion into string : "<<str;
    return 0;
}

