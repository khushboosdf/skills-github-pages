#include<iostream>
#include<string.h>
#include<sstream>

using namespace std;

int main()
{
    int a;
    char ch;
    cout<<"Enter the integer which you want to change it into char : ";
    cin>>a;
    ch='0'+a;
    cout<<"Integer after conversion into character : "<<ch;
    return 0;
}
