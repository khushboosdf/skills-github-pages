#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    ifstream f("File1");
    string word;
    int count=0;
    while (f>>word)
	{
        count++;
    }
    cout << "Number of words in the file: " << count;
    f.close();
    return 0;
}


