#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() 
{
    ifstream f("File1");
    ofstream f1("File2");
    char ch;
    while (f.get(ch))
	{
        f1.put(ch);
    }
    cout << "File copied.";

    f.close();
    f1.close();

    return 0;
}

