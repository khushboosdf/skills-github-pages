#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int main(){
    fstream f;
    char ch;
    int c=0;
    f.open("File1",ios::in);
    while(!f.eof()){
    f.get(ch);
    if(ch=='\n'){
        c++;
    }
  }
  cout<<"No of lines in file : "<<c+1;
  f.close();
  return 0;
}