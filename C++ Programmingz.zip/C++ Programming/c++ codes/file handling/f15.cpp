#include <iostream>
#include <fstream>

using namespace std;

int main() 
{
    string filename;
    double number, sum = 0.0;
    int count = 0;

    ifstream f("File7");
    if (!f)
	 {
        cout << "Error opening file." << endl;
        return 1;
    }
    while (f >> number) 
	{
        sum += number;
        count++;
    }
    f.close();

    if (count == 0)
	 {
        cout << "No numbers found in the file." << endl;
    } else 
	{
        cout << "Average of numbers in the file: " << sum / count;
    }

    return 0;
}


