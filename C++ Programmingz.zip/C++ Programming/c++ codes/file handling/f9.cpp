#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int main(){
    fstream f1,f2,f3;
    string l[10],st;

    f1.open("File1",ios::in);
    f2.open("File3",ios::in);
    f3.open("MergeFile",ios::out);

    while(!f1.eof()){
    getline(f1,st);
        f3<<st<<endl;
      }
      
   f1.close();
   f3.close();
   f3.open("MergeFile",ios::app);
   while(!f2.eof()){
     getline(f2,st);
     f3<<st<<endl;
      }

    cout<<"Data merged in one file.";
    f2.close();
    f3.close();
  return 0;
}