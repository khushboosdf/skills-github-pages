#include<iostream>
#include<fstream>
#include<string>

using namespace std;

int main()
{
    fstream f;
    string str;
    f.open("File2",ios::in);
    while(!f.eof()){
    getline(f,str);
  }
  cout<<"Data inside file : "<<endl<<str;
  f.close();
  return 0;
}