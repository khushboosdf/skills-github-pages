#include<iostream>

using namespace std;

class Time
{
	int hour;
	int min;
	public:
		void get()
		{
			cout<<"Enter hour : ";
			cin>>hour;
			cout<<"Enter minutes : ";
			cin>>min;
		}
		void display()
		{
			cout<<"Entered time : "<<hour<<":"<<min;
		}
};

int main()
{
	Time obj1;
	obj1.get();
	obj1.display();
}