#include<iostream>

using namespace std;

class Fraction
{
	int n,d;
	public :
		void get();
		Fraction operator+(Fraction x)
		{
			Fraction a;
			a.n=(n*x.d)+(d*x.n);
			a.d=d*x.d;
			return a;
		}
		void display();
};

void Fraction::get()
{
	cout<<"Enter numerator : ";
	cin>>n;
	cout<<"Enter denominator : ";
	cin>>d;
}

void Fraction::display()
{
	cout<<"Addition of Fraction : "<<n<<" / "<<d;
}

int main()
{
	Fraction n1,n2,ans;
	n1.get();
	n2.get();
	ans=n1+n2;
	ans.display();
}

