#include<iostream>
#include<string.h>

using namespace std;

class String
{
	 string str;

	public:
		void get()
		{
			cout<<"Enter a string : ";
			cin>>str;
		}
		void display()
		{
			cout<<endl<<"Entered String : "<<str;
		}
		operator+(String& s)
		{
			cout<<endl<<str<<" "<<s.str;
			
		}
};

int main()
{
	String obj1,obj2;
	obj1.get();
	obj2.get();
	obj1.display();
	obj2.display();
	obj1+obj2;
}

