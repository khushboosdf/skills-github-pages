#include <iostream>
#include <string>
#include <vector>

void generate_permutations(const std::string& str, std::string current_permutation, std::vector<std::string>& permutations) {
    // Base case: if current_permutation is a full permutation of str, add it to the list of permutations
    if (current_permutation.length() == str.length()) {
        permutations.push_back(current_permutation);
        return;
    }

    // Recursively generate permutations by swapping characters
    for (int i = 0; i < str.length(); ++i) {
        if (current_permutation.find(str[i]) == std::string::npos) { // Skip if character already exists in current_permutation
            generate_permutations(str, current_permutation + str[i], permutations);
        }
    }
}

int main() {
    std::string input_string;

    // Input string
    std::cout << "Enter a string: ";
    std::cin >> input_string;

    // Vector to store all permutations
    std::vector<std::string> permutations;

    // Generate permutations
    generate_permutations(input_string, "", permutations);

    // Output result
    std::cout << "All permutations of the string:" << std::endl;
    for (const auto& permutation : permutations) {
        std::cout << permutation << std::endl;
    }

    return 0;
}
