#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

int main()
{
    cout<<"The Current Date is: "<<__DATE__<<endl;
    cout<<"The Current Time is: "<<__TIME__<<endl;
    return 0;
}
