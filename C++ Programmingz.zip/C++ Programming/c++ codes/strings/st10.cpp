#include<iostream>
#include<conio.h>
#include<string.h>

using namespace std;

int main()
{
    char str[]="Hello World";
    cout<<"The number of characters in the string is: "<<strlen(str);   
    return 0;
}
