#include <iostream>
#include <string>

bool is_rotation(const std::string& str1, const std::string& str2) {
    // Check if both strings have the same length and are not empty
    if (str1.length() != str2.length() || str1.empty()) {
        return false;
    }

    // Concatenate str1 with itself
    std::string concatenated = str1 + str1;

    // Check if str2 is a substring of the concatenated string
    return concatenated.find(str2) != std::string::npos;
}

int main() {
    std::string str1, str2;

    // Input strings
    std::cout << "Enter the first string: ";
    std::cin >> str1;
    std::cout << "Enter the second string: ";
    std::cin >> str2;

    // Check if str2 is a rotation of str1
    if (is_rotation(str1, str2)) {
        std::cout << "The second string is a rotation of the first string." << std::endl;
    } else {
        std::cout << "The second string is not a rotation of the first string." << std::endl;
    }

    return 0;
}
