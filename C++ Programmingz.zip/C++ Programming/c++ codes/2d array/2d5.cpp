#include<iostream>
#include<conio.h>

using namespace std;

int main()
{    
    int m,n,p,q;

    //Input Dimensions for the First Matrix
    cout<<"Enter the number of Rows and Columns for First Matrix: ";
    cin>>m>>n;

    //Input Dimensions for the Second Matrix
    cout<<"Enter the number of Rows and Columns for Second Matrix: ";
    cin>>p>>q;
   
   //Initialize Matrices
    int a[m][n];
    int b[p][q];
    int result[m][q];
    int c=1;
    //Input Dimensions for First Matrix
    cout<<"Enter Elements for Matrix: "<<endl;
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            cin>>a[i][j];
        }
    }

    //Input Dimensions for Second Matrix
     cout<<"Enter Elements for Second Matrix: "<<endl;
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
            cin>>b[i][j];
        }
    }

    //Display First Matrix
    cout<<"First Matrix: "<<endl;
    for(int i=0; i<m; i++){
        for(int j=0; j<n; j++){
            cout<<a[i][j]<<'\t';
        }
        cout<<endl;
    }

    //Display Second Matrix
    cout<<"Second Matrix: "<<endl;
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
            cout<<b[i][j]<<'\t';
        }
        cout<<endl;
    }

    //Check that first and second are equal or not 
    for(int i=0; i<m; i++){
        for(int j=0; i<n; i++){
            if(a[i][j]!=b[i][j]){
               c = 0;
               break;
            } 
        }
    }
    if(c==1){
        cout<<"First and Second Matrix are equal"<<endl;
     }
     else{ 
        cout<<"First and Second Matrix are not equal"<<endl;
    }
    return 0;
}