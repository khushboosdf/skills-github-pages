#include<iostream>
#include<conio.h>

using namespace std;

int main()
{    
    int n,m,p,q;

    //Input Dimensions for the First Matrix
    cout<<"Enter the number of Rows and Columns for First Matrix: ";
    cin>>n>>m;

    //Input Dimensions for the Second Matrix
    cout<<"Enter the number of Rows and Columns for Second Matrix: ";
    cin>>p>>q;
   
   //Initialize Matrices
    int mat1[n][m];
    int mat2[p][q];
    int result[m][q];
    //Input Dimensions for First Matrix
    cout<<"Enter Elements for Matrix: "<<endl;
    for(int i=0; i<n; i++){
        for(int j=0; j<m; j++){
            cin>>mat1[i][j];
        }
    }

    //Input Dimensions for Second Matrix
     cout<<"Enter Elements for Second Matrix: "<<endl;
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
            cin>>mat2[i][j];
        }
    }

    //Performing Matrix Substraction 
    for(int i=0; i<p; i++){
        for(int j=0; j<q; j++){
             result[i][j]= mat1[i][j] - mat2[i][j];
        }
    }

    //Display the sum
    cout<<"Substraction of First and Second Matrix is: "<<endl;
    for(int i=0; i<m; i++){
        for(int j=0; j<p; j++){
            cout<<result[i][j]<<'\t';
        }
    cout<<endl;
    }
    return 0;
}
