#include <iostream>
#include<conio.h>
using namespace std;

int main() 
{
    int m, n;
    cout<<"Enter the number of rows: ";
    cin>>m;
    cout<<"Enter the number of columns: ";
    cin>>n;

    int mat[m][n];

    cout<<"Enter the elements of the matrix:" << endl;
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n; ++j) {
                cin>>mat[i][j];
        }
    }

    // Calculate row sums
    cout<<"\nRow sums:"<<endl;
    for (int i= 0; i<m; ++i) {
        int row=0;
        for (int j=0; j<n; ++j) {
            row += mat[i][j];
        }
        cout<<"Sum of row "<<i<<": "<<row<<endl;
    }

    // Calculate column sums
    cout << "\nColumn sums:" << endl;
    for (int j=0; j<n; ++j) {
        int col=0;
        for (int i=0; i<m; ++i) {
            col += mat[i][j];
        }
        cout<<"Sum of column "<<j<<": "<<col<< endl;
    }

    return 0;
}