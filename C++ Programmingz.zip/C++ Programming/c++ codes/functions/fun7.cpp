#include <iostream>
#include <string>

using namespace std;

char areAllVowels(const string& str) {
    for (char c : str) {
        if (c != 'a' && c != 'e' && c != 'i' && c != 'o' && c != 'u' &&
            c != 'A' && c != 'E' && c != 'I' && c != 'O' && c != 'U') {
            return '0';
        }
    }
    return '1'; 
}

int main() {
    string input;
    cout << "Enter a string: ";
    cin >> input;

    if (areAllVowels(input) == '1') {
        cout << "All characters are vowels." << endl;
    } else {
        cout << "Not all characters are vowels." << endl;
    }

    return 0;
}