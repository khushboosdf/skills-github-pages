#include <iostream>
#include<conio.h>

using namespace std;

void findTwinPrimes();

int main() {
    findTwinPrimes();
    return 0;
}

void findTwinPrimes() {
    cout << "Twin prime numbers less than 100:" << endl;
    for (int i = 3; i < 100 - 2; ++i) {
        int isTwinPrime = 1;
        for (int j = 2; j * j <= i + 2; ++j) {
            if (i % j == 0 || (i + 2) % j == 0) {
                isTwinPrime = 0;
                break;
            }
        }
        if (isTwinPrime) {
            cout << i << " and " << i + 2 << endl;
        }
    }
}