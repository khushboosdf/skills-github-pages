#include<iostream>
#include<conio.h>
using namespace std;

void consecutivenum(int a, int b, int c);

int main()
{
    int a,b,c;
    cout<<"Enter three Integers: ";
    cin>>a>>b>>c;
    consecutivenum(a,b,c);
    return 0;
}

void consecutivenum(int a, int b, int c){
    if (a== b - 1 && b== c - 1)
    {
        cout<<"True"<<endl;
        cout<<"They are consecutive integers";
    }
    else if(a== b + 1 && b== c + 1){
    cout<<"True"<<endl;
    cout<<"They are consecutive integers";
    }
    else{
    cout<<"False"<<endl;
    cout<<"They are not consecutive integers";
    }
}
