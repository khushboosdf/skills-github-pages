#include <iostream>
#include <string>
#include<conio.h>

using namespace std;

void displayMiddleCharacter(string& str);

int main() {
    string ch;
    cout<<"Enter a string: ";
    cin>>ch;

    displayMiddleCharacter(ch);
    return 0;
}

void displayMiddleCharacter(string& str) {
    int length = str.length();
    int middle = length / 2;

    if (length % 2 == 0) {
        cout << "Middle character(s): " << str.substr(middle - 1, 2) << endl;
    } else {
        cout << "Middle character: " << str[middle] << endl;
    }
}