#include<iostream>

using namespace std;

int count(int n);

int main(){
    int n;
    cout<<"Enter the number : ";
    cin>>n;
    cout<<"No. of digits with value 2 : "<<count(n);
    return 0;
    }

int count(int n){
    int c=0,r;
    while(n!=0){
       r=n%10;
       if(r==2){
        c++;
       }
       n/=10;
    }
    return c;
    }
